CREATE PROCEDURE SendMessageToAllUsers
    --todo max
    @MessageContent VARCHAR(MAX)
AS
BEGIN

    DECLARE @UserId INT;
    DECLARE @UserEmail VARCHAR(200);


    DECLARE user_cursor CURSOR FOR
        SELECT Id, email FROM Users;

    OPEN user_cursor;


    FETCH NEXT FROM user_cursor INTO @UserId, @UserEmail;


    WHILE @@FETCH_STATUS = 0
    BEGIN

        PRINT 'Sending message to User ID ' + CONVERT(VARCHAR, @UserId) + ' at ' + @UserEmail;


        FETCH NEXT FROM user_cursor INTO @UserId, @UserEmail;
    END


    CLOSE user_cursor;
    DEALLOCATE user_cursor;
END
go

