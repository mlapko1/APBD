CREATE PROCEDURE CompileChannelStatistics
    @channelId INT

AS
BEGIN
 Declare   @NumberOfMessages INT,
    @AvgMessageLength INT,
    @ActiveUsers INT;


    SET @NumberOfMessages = (SELECT COUNT(*) FROM Message WHERE Channel_user_Channel_Id = @channelId);
    PRINT CONVERT( VARCHAR ,@NumberOfMessages) + ' Total number of messages';



    SET @ActiveUsers = (SELECT COUNT(DISTINCT User_Id) FROM Channel_user WHERE Channel_Id = @channelId);
    Print  CONVERT( VARCHAR ,@ActiveUsers )+ ' Number of active users';


    SET @AvgMessageLength = (SELECT AVG(LEN(text)) FROM Message WHERE Channel_user_Channel_Id = @channelId);
    PRINT  CONVERT( VARCHAR ,@AvgMessageLength) + ' Average message length';
END
go

